                        WELD DATA FROM PCF FILES

1. The utility doesn't need the installations, just unzip it to any folder and run PCF-Reader.exe

2. The list of attributes that will be shown in the final export is
   configured through the config.ini file.

3. In case of error "Columns not found in data: col_name" 
   remove col_name from WELD_ATTRIBUTES list in config.ini file

4. The test case pcf's that software was tested on it is in folder fixtures\test_pcf 


Contact with the author: igor@gazintek.com